defmodule BlockScoutWeb.Tokens.ContractView do
  use BlockScoutWeb, :view

  alias BlockScoutWeb.Tokens.OverviewView
  alias Explorer.Chain.Address
end
