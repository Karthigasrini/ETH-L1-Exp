defmodule BlockScoutWeb.WithdrawalView do
  use BlockScoutWeb, :view
end
