defmodule BlockScoutWeb.AddressContractVerificationView do
  use BlockScoutWeb, :view

  alias Explorer.SmartContract.RustVerifierInterface
end
