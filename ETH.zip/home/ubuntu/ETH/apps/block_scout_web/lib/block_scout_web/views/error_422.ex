defmodule BlockScoutWeb.Error422View do
  use BlockScoutWeb, :view

  @dialyzer :no_match
end
